import { Router } from "express";
import { eq, desc } from "drizzle-orm";
import { db, tasksTable } from "@workspace/db";
import { sql } from "drizzle-orm";

const router = Router();

// Dashboard stats
router.get("/stats", async (req, res) => {
  try {
    const rows = await db
      .select({ status: tasksTable.status, count: sql<number>`count(*)::int` })
      .from(tasksTable)
      .groupBy(tasksTable.status);

    const stats = { total: 0, pending: 0, inProgress: 0, completed: 0 };

    for (const row of rows) {
      stats.total += row.count;
      if (row.status === "pending") stats.pending = row.count;
      else if (row.status === "in_progress") stats.inProgress = row.count;
      else if (row.status === "completed") stats.completed = row.count;
    }

    res.json(stats);
  } catch (err) {
    req.log.error({ err }, "Error fetching dashboard stats");
    res.status(500).json({ error: "Failed to fetch stats" });
  }
});

// Recent tasks
router.get("/recent", async (req, res) => {
  try {
    const tasks = await db
      .select()
      .from(tasksTable)
      .orderBy(desc(tasksTable.createdAt))
      .limit(5);

    res.json(
      tasks.map((task) => ({
        id: task.id,
        title: task.title,
        description: task.description ?? null,
        status: task.status,
        dueDate: task.dueDate ?? null,
        createdAt: task.createdAt.toISOString(),
        updatedAt: task.updatedAt.toISOString(),
      }))
    );
  } catch (err) {
    req.log.error({ err }, "Error fetching recent tasks");
    res.status(500).json({ error: "Failed to fetch recent tasks" });
  }
});

export default router;
