import { Router } from "express";
import { eq, desc, asc, ilike, or, and } from "drizzle-orm";
import { db, tasksTable, insertTaskSchema, updateTaskSchema } from "@workspace/db";
import { z } from "zod/v4";

const router = Router();

// List tasks with optional search, filter, sort
router.get("/", async (req, res) => {
  try {
    const { search, status, sort } = req.query as {
      search?: string;
      status?: string;
      sort?: string;
    };

    const conditions = [];

    if (status && ["pending", "in_progress", "completed"].includes(status)) {
      conditions.push(eq(tasksTable.status, status));
    }

    if (search && search.trim()) {
      const term = `%${search.trim()}%`;
      conditions.push(
        or(ilike(tasksTable.title, term), ilike(tasksTable.description, term))
      );
    }

    const orderBy = sort === "oldest" ? asc(tasksTable.createdAt) : desc(tasksTable.createdAt);

    const tasks = await db
      .select()
      .from(tasksTable)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(orderBy);

    res.json(tasks.map(formatTask));
  } catch (err) {
    req.log.error({ err }, "Error listing tasks");
    res.status(500).json({ error: "Failed to fetch tasks" });
  }
});

// Create a task
router.post("/", async (req, res) => {
  try {
    const parsed = insertTaskSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }

    const [task] = await db
      .insert(tasksTable)
      .values(parsed.data)
      .returning();

    res.status(201).json(formatTask(task));
  } catch (err) {
    req.log.error({ err }, "Error creating task");
    res.status(500).json({ error: "Failed to create task" });
  }
});

// Get a single task
router.get("/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "Invalid task ID" });

    const [task] = await db.select().from(tasksTable).where(eq(tasksTable.id, id));

    if (!task) return res.status(404).json({ error: "Task not found" });

    res.json(formatTask(task));
  } catch (err) {
    req.log.error({ err }, "Error getting task");
    res.status(500).json({ error: "Failed to fetch task" });
  }
});

// Update a task
router.patch("/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "Invalid task ID" });

    const parsed = updateTaskSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.message });
    }

    const [existing] = await db.select().from(tasksTable).where(eq(tasksTable.id, id));
    if (!existing) return res.status(404).json({ error: "Task not found" });

    const [updated] = await db
      .update(tasksTable)
      .set({ ...parsed.data, updatedAt: new Date() })
      .where(eq(tasksTable.id, id))
      .returning();

    res.json(formatTask(updated));
  } catch (err) {
    req.log.error({ err }, "Error updating task");
    res.status(500).json({ error: "Failed to update task" });
  }
});

// Delete a task
router.delete("/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (isNaN(id)) return res.status(400).json({ error: "Invalid task ID" });

    const [existing] = await db.select().from(tasksTable).where(eq(tasksTable.id, id));
    if (!existing) return res.status(404).json({ error: "Task not found" });

    await db.delete(tasksTable).where(eq(tasksTable.id, id));

    res.status(204).end();
  } catch (err) {
    req.log.error({ err }, "Error deleting task");
    res.status(500).json({ error: "Failed to delete task" });
  }
});

function formatTask(task: typeof tasksTable.$inferSelect) {
  return {
    id: task.id,
    title: task.title,
    description: task.description ?? null,
    status: task.status,
    dueDate: task.dueDate ?? null,
    createdAt: task.createdAt.toISOString(),
    updatedAt: task.updatedAt.toISOString(),
  };
}

export default router;
