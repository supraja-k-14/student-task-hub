import { Badge } from "@/components/ui/badge";

type TaskStatus = "pending" | "in_progress" | "completed";

export function StatusBadge({ status }: { status: TaskStatus | string }) {
  switch (status) {
    case "pending":
      return <Badge variant="outline" className="bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800/50">Pending</Badge>;
    case "in_progress":
      return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-900/30 dark:text-blue-300 dark:border-blue-800/50">In Progress</Badge>;
    case "completed":
      return <Badge variant="outline" className="bg-emerald-100 text-emerald-800 border-emerald-200 dark:bg-emerald-900/30 dark:text-emerald-300 dark:border-emerald-800/50">Completed</Badge>;
    default:
      return <Badge variant="outline" className="capitalize">{status?.replace("_", " ")}</Badge>;
  }
}
