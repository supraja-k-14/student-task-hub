import { useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useCreateTask, useGetTask, useUpdateTask, useDeleteTask, getGetTaskQueryKey, getListTasksQueryKey } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { CalendarIcon, ArrowLeft, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";

const formSchema = z.object({
  title: z.string().min(1, "Title is required").max(200, "Title is too long"),
  description: z.string().optional(),
  status: z.enum(["pending", "in_progress", "completed"]),
  dueDate: z.date().optional().nullable(),
});

type FormValues = z.infer<typeof formSchema>;

export default function TaskForm() {
  const [, setLocation] = useLocation();
  const params = useParams();
  const isNew = !params.id || params.id === "new";
  const taskId = isNew ? undefined : parseInt(params.id as string, 10);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: task, isLoading: isTaskLoading } = useGetTask(taskId as number, {
    query: {
      enabled: !isNew && !!taskId,
      queryKey: getGetTaskQueryKey(taskId as number),
    }
  });

  const createTask = useCreateTask({
    mutation: {
      onSuccess: () => {
        toast({ title: "Task created successfully" });
        queryClient.invalidateQueries({ queryKey: getListTasksQueryKey() });
        setLocation("/tasks");
      },
      onError: () => {
        toast({ title: "Failed to create task", variant: "destructive" });
      }
    }
  });

  const updateTask = useUpdateTask({
    mutation: {
      onSuccess: () => {
        toast({ title: "Task updated successfully" });
        if (taskId) {
          queryClient.invalidateQueries({ queryKey: getGetTaskQueryKey(taskId) });
        }
        queryClient.invalidateQueries({ queryKey: getListTasksQueryKey() });
        setLocation("/tasks");
      },
      onError: () => {
        toast({ title: "Failed to update task", variant: "destructive" });
      }
    }
  });

  const deleteTask = useDeleteTask({
    mutation: {
      onSuccess: () => {
        toast({ title: "Task deleted successfully" });
        queryClient.invalidateQueries({ queryKey: getListTasksQueryKey() });
        setLocation("/tasks");
      },
      onError: () => {
        toast({ title: "Failed to delete task", variant: "destructive" });
      }
    }
  });

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      status: "pending",
      dueDate: null,
    },
  });

  useEffect(() => {
    if (task && !isNew) {
      form.reset({
        title: task.title,
        description: task.description || "",
        status: task.status,
        dueDate: task.dueDate ? new Date(task.dueDate) : null,
      });
    }
  }, [task, isNew, form]);

  const onSubmit = (values: FormValues) => {
    const apiData = {
      title: values.title,
      description: values.description,
      status: values.status,
      dueDate: values.dueDate ? values.dueDate.toISOString() : undefined,
    };

    if (isNew) {
      createTask.mutate({ data: apiData });
    } else if (taskId) {
      updateTask.mutate({ id: taskId, data: apiData });
    }
  };

  const isPending = createTask.isPending || updateTask.isPending;

  if (!isNew && isTaskLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-32" />
        <Card>
          <CardContent className="p-6 space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-10 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <Button variant="ghost" className="gap-2 -ml-4" onClick={() => setLocation("/tasks")}>
          <ArrowLeft className="w-4 h-4" /> Back to Tasks
        </Button>
        {!isNew && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm" className="gap-2">
                <Trash2 className="w-4 h-4" /> Delete Task
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete your task.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  onClick={() => taskId && deleteTask.mutate({ id: taskId })}
                >
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>

      <Card className="border-t-4 border-t-primary shadow-md">
        <CardHeader>
          <CardTitle className="text-2xl font-serif">{isNew ? "Create New Task" : "Edit Task"}</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-semibold text-foreground">Title <span className="text-destructive">*</span></FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Complete Literature Review" {...field} className="bg-background" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="font-semibold text-foreground">Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Add some details, links, or notes..." 
                        className="min-h-[120px] bg-background resize-y" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="font-semibold text-foreground">Status</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value} value={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-background">
                            <SelectValue placeholder="Select a status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="in_progress">In Progress</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="dueDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel className="font-semibold text-foreground mb-1.5">Due Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal bg-background w-full",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value || undefined}
                            onSelect={field.onChange}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex justify-end pt-4 border-t">
                <Button type="submit" disabled={isPending} className="px-8 font-medium">
                  {isPending ? "Saving..." : isNew ? "Create Task" : "Save Changes"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
