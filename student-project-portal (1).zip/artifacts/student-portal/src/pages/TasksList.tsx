import { useState } from "react";
import { useListTasks, ListTasksStatus, ListTasksSort } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StatusBadge } from "@/components/status-badge";
import { format } from "date-fns";
import { Search, Plus, Calendar, Inbox } from "lucide-react";
import { useDebounce } from "@/hooks/use-debounce";

// Hook helper for simple debounce
function useDebounceValue<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);
  
  React.useEffect(() => {
    const timer = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);

  return debouncedValue;
}
import * as React from "react";

export default function TasksList() {
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebounceValue(search, 300);
  const [status, setStatus] = useState<ListTasksStatus | "all">("all");
  const [sort, setSort] = useState<ListTasksSort>("newest");

  const queryParams = {
    ...(debouncedSearch ? { search: debouncedSearch } : {}),
    ...(status !== "all" ? { status: status as ListTasksStatus } : {}),
    sort,
  };

  const { data: tasks, isLoading } = useListTasks(queryParams, {
    query: {
      queryKey: ["tasks", queryParams],
    }
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-serif font-bold tracking-tight">Tasks</h2>
          <p className="text-muted-foreground mt-1">Manage and track your project tasks.</p>
        </div>
        <Link href="/tasks/new">
          <Button className="gap-2">
            <Plus className="w-4 h-4" /> New Task
          </Button>
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 bg-card p-4 rounded-lg border shadow-sm">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search tasks..." 
            className="pl-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select value={status} onValueChange={(val: any) => setStatus(val)}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
          </SelectContent>
        </Select>
        <Select value={sort} onValueChange={(val: any) => setSort(val)}>
          <SelectTrigger className="w-full sm:w-[180px]">
            <SelectValue placeholder="Sort order" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="newest">Newest First</SelectItem>
            <SelectItem value="oldest">Oldest First</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-4">
        {isLoading ? (
          Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))
        ) : tasks?.length === 0 ? (
          <div className="py-16 flex flex-col items-center justify-center text-center border border-dashed rounded-lg bg-card/50">
            <Inbox className="w-12 h-12 text-muted-foreground/50 mb-4" />
            <h3 className="text-lg font-medium">No tasks found</h3>
            <p className="text-muted-foreground max-w-sm mt-1 mb-4">
              {search || status !== "all" 
                ? "Try adjusting your search or filters to find what you're looking for."
                : "You don't have any tasks yet. Create one to get started."}
            </p>
            {!(search || status !== "all") && (
              <Link href="/tasks/new">
                <Button>Create your first task</Button>
              </Link>
            )}
          </div>
        ) : (
          tasks?.map((task) => (
            <Link key={task.id} href={`/tasks/${task.id}`}>
              <Card className="group hover:border-primary/50 transition-all cursor-pointer">
                <CardContent className="p-5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="space-y-1.5 flex-1 min-w-0">
                      <div className="flex items-center gap-3">
                        <h3 className="font-semibold text-lg truncate group-hover:text-primary transition-colors">
                          {task.title}
                        </h3>
                        <StatusBadge status={task.status} />
                      </div>
                      {task.description && (
                        <p className="text-muted-foreground text-sm line-clamp-2">
                          {task.description}
                        </p>
                      )}
                    </div>
                    <div className="flex items-center text-sm text-muted-foreground shrink-0 bg-muted/50 px-3 py-1.5 rounded-md">
                      <Calendar className="w-4 h-4 mr-2" />
                      {task.dueDate ? format(new Date(task.dueDate), "MMM d, yyyy") : "No due date"}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
