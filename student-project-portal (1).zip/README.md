# Student Mini Project Management Portal

A full-stack web application for students to create, track, and manage their mini-project tasks — from planning through completion. Built with React, Vite, TypeScript, Express, and PostgreSQL.

---

## Features

- **Task Management** — Create, edit, delete tasks with title, description, status, and due date
- **Dashboard Statistics** — Live counters for Total, Pending, In Progress, and Completed tasks
- **Search Tasks** — Real-time search by title or description
- **Filter by Status** — Filter tasks by Pending / In Progress / Completed
- **Sort Tasks** — Sort by Newest First or Oldest First
- **Dark Mode** — Toggle with localStorage persistence across sessions
- **Toast Notifications** — Success and error feedback on every action
- **Confirmation Modals** — Safe delete flow with AlertDialog confirmation
- **Loading Skeletons** — Smooth loading states on all data-fetching views
- **Empty State Screens** — Friendly messages when no tasks exist or match filters
- **REST API Integration** — Axios-powered API client generated from OpenAPI spec
- **Client-side Validation** — React Hook Form + Zod with inline field errors
- **Server-side Validation** — Zod schemas on every API endpoint
- **Centralized Error Handling** — Consistent error responses and user-facing toasts
- **Responsive UI** — Works on mobile, tablet, and desktop
- **PostgreSQL Integration** — Drizzle ORM with automatic schema push

---

## Tech Stack

### Frontend
| Technology | Purpose |
|---|---|
| React 19 | UI framework |
| Vite | Build tool & dev server |
| TypeScript | Type safety |
| Tailwind CSS | Utility-first styling |
| TanStack Query | Server state management |
| React Hook Form | Form state management |
| Zod | Schema validation |
| Wouter | Client-side routing |
| Sonner / Radix UI | Toast notifications & modals |
| next-themes | Dark mode support |
| Axios | HTTP client |

### Backend
| Technology | Purpose |
|---|---|
| Node.js 24 | Runtime |
| Express 5 | HTTP framework |
| TypeScript | Type safety |
| Drizzle ORM | Database ORM |
| PostgreSQL | Database |
| Zod | Request/response validation |
| Pino | Structured logging |
| esbuild | Server bundler |

### Tooling
| Technology | Purpose |
|---|---|
| pnpm workspaces | Monorepo package management |
| Orval | OpenAPI → TypeScript hooks codegen |
| drizzle-kit | Database schema management |
| TypeScript Project References | Cross-package type checking |

---

## Project Structure

```
student-project-portal/
├── artifacts/
│   ├── student-portal/          # React + Vite frontend app
│   │   └── src/
│   │       ├── pages/           # Dashboard, TaskList, TaskForm, TaskDetail
│   │       ├── components/      # UI components (layout, badges, modals)
│   │       └── App.tsx          # Root with routing and providers
│   └── api-server/              # Express REST API server
│       └── src/
│           ├── routes/          # /tasks, /dashboard endpoints
│           ├── middlewares/     # Error handling, request logging
│           └── app.ts           # Express app setup
├── lib/
│   ├── db/                      # Drizzle ORM schema + client
│   │   └── src/schema/          # tasks table definition
│   ├── api-spec/                # OpenAPI 3.1 specification (source of truth)
│   │   └── openapi.yaml
│   ├── api-client-react/        # Generated React Query hooks (from OpenAPI)
│   └── api-zod/                 # Generated Zod schemas (from OpenAPI)
├── pnpm-workspace.yaml          # Workspace config & catalog
├── tsconfig.base.json           # Shared TypeScript strict defaults
└── tsconfig.json                # Root solution file for lib packages
```

---

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/healthz` | Health check |
| GET | `/api/tasks` | List all tasks (supports `?search=`, `?status=`, `?sort=`) |
| POST | `/api/tasks` | Create a new task |
| GET | `/api/tasks/:id` | Get a task by ID |
| PATCH | `/api/tasks/:id` | Update a task |
| DELETE | `/api/tasks/:id` | Delete a task |
| GET | `/api/dashboard/stats` | Get task counts by status |
| GET | `/api/dashboard/recent` | Get 5 most recently created tasks |

---

## Getting Started

### Prerequisites

- [Node.js 20+](https://nodejs.org/)
- [pnpm 9+](https://pnpm.io/installation)
- [PostgreSQL](https://www.postgresql.org/) database

### 1. Clone the repository

```bash
git clone https://github.com/your-username/student-project-portal.git
cd student-project-portal
```

### 2. Install dependencies

```bash
pnpm install
```

### 3. Configure environment variables

Create a `.env` file in the root (or set these in your environment):

```env
DATABASE_URL=postgresql://user:password@localhost:5432/student_portal
SESSION_SECRET=your-random-secret-here
```

### 4. Push the database schema

```bash
pnpm --filter @workspace/db run push
```

### 5. Start the API server

```bash
pnpm --filter @workspace/api-server run dev
```

The API server runs on port `5000` (or the `PORT` env var).

### 6. Start the frontend

```bash
pnpm --filter @workspace/student-portal run dev
```

The frontend runs on `http://localhost:5173` by default.

---

## Scripts

| Command | Description |
|---|---|
| `pnpm --filter @workspace/api-server run dev` | Start API server (dev mode with rebuild) |
| `pnpm --filter @workspace/student-portal run dev` | Start frontend dev server |
| `pnpm run typecheck` | Full typecheck across all packages |
| `pnpm run build` | Build all packages |
| `pnpm --filter @workspace/api-spec run codegen` | Regenerate API hooks and Zod schemas from OpenAPI spec |
| `pnpm --filter @workspace/db run push` | Push DB schema changes (dev only) |

---

## Database Schema

```sql
CREATE TABLE tasks (
  id          SERIAL PRIMARY KEY,
  title       VARCHAR(200) NOT NULL,
  description TEXT,
  status      VARCHAR(20) NOT NULL DEFAULT 'pending',
  due_date    VARCHAR(30),
  created_at  TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMP NOT NULL DEFAULT NOW()
);
```

**Status values:** `pending` | `in_progress` | `completed`

---

## Screenshots

### Dashboard
The main dashboard shows live task statistics and recent activity.

### Task List
Search, filter by status, and sort tasks in real time.

### Dark Mode
Full dark mode support with localStorage persistence.

---

## Development Notes

- **API contract-first:** The OpenAPI spec (`lib/api-spec/openapi.yaml`) is the source of truth. Run `codegen` after any spec changes.
- **No direct cross-artifact imports:** Frontend and backend never import from each other — communication is only through the REST API.
- **Shared libs:** `@workspace/db` and `@workspace/api-client-react` are consumed by both server and client respectively.
- **Logging:** Uses `pino` structured logging on the server. Never use `console.log` in server code — use `req.log` in route handlers.

---

## License

MIT License — feel free to use this project as a template for your own student projects.
