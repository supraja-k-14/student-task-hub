# Student Mini Project Management Portal

A full-stack task management web app for students, built with React + Vite (frontend) and Express + PostgreSQL (backend) in a pnpm monorepo.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080, proxied at /api)
- `pnpm --filter @workspace/student-portal run dev` — run the frontend (proxied at /)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React 19, Vite, Tailwind CSS, TanStack Query, React Hook Form, Zod, Wouter
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — OpenAPI 3.1 spec (source of truth for all API contracts)
- `lib/db/src/schema/tasks.ts` — Drizzle ORM tasks table schema
- `artifacts/api-server/src/routes/` — Express route handlers (tasks, dashboard, health)
- `artifacts/student-portal/src/pages/` — React pages (Dashboard, TaskList, TaskForm, TaskDetail)
- `artifacts/student-portal/src/components/` — Shared UI components
- `lib/api-client-react/src/generated/api.ts` — Generated React Query hooks (do not edit manually)
- `lib/api-zod/src/generated/api.ts` — Generated Zod schemas (do not edit manually)

## Architecture decisions

- Contract-first API: OpenAPI spec is written first, code is generated from it. Never edit generated files.
- PostgreSQL via Drizzle ORM with `drizzle-kit push` for dev schema migrations.
- Dark mode implemented via next-themes with localStorage persistence and `dark` class on `<html>`.
- All search/filter/sort on tasks is done server-side via query params on `GET /api/tasks`.
- Status is a varchar with app-level enum enforcement (not a Postgres enum) for flexibility.

## Product

Full CRUD task management portal for students:
- Dashboard with live stats (total/pending/in-progress/completed) and recent tasks
- Task list with search, filter by status, sort by date
- Create/edit/delete tasks with validation and confirmation modals
- Dark mode toggle, toast notifications, loading skeletons, empty states
- Responsive layout for mobile and desktop

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Run `pnpm --filter @workspace/api-spec run codegen` after any change to `openapi.yaml` before editing frontend hooks.
- API server must be restarted after code changes (it builds with esbuild before starting).
- Do NOT use `console.log` in server code — use `req.log` (route handlers) or `logger` (non-request code).
- `DATABASE_URL` must be set in the environment for the API server and DB push to work.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
